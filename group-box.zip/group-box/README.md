# LOVEOS GROUP BOX — Portable Security Root Box

**CEO TroyFeeney · LOVE OS Inc © 2026 · 100% royalties · copyright ownership policy terms rules · custom built · custom built add-on · everything tools kits**

Custom built for CEO TroyFeeney / LOVE OS Inc. All copyright, ownership, control, and 100% royalties remain with CEO TroyFeeney / LOVE OS Inc. No ownership, resale, distribution, or commercial rights are granted to anyone else.

## What it is

One dependency-free Node.js file — `group-box.js` — that runs anywhere Node runs: Windows, macOS, Linux, and Termux on Android. No installs, no packages, nothing to compile. It does three defensive, read-only jobs:

| Command | What it does |
|---|---|
| `fleet` | Checks the 4 LOVEOS servers (Network :8787, Live Wall :8788, Game :8789, GHOST :8790) and prints UP/DOWN for each |
| `scan <file-or-dir>` | SHA-256 integrity scan — hashes every file and reports size + hash, so you can prove a file never changed |
| `ports` | Checks a short list of common ports on THIS machine only (127.0.0.1) and reports open/closed |
| `help` | Prints usage |

**Honest line: defensive checks on your own machines only.** No exploitation, no brute force, no intrusion — the port check is a plain connect to your own localhost, and every command is read-only. Nothing here touches other people's systems.

## Requirements

Node.js (any modern version). Check yours with `node --version`.

## Exact commands

### Windows (Command Prompt or PowerShell)
```
cd group-box
node group-box.js fleet
node group-box.js scan C:\path\to\file-or-folder
node group-box.js ports
node group-box.js help
```

### macOS / Linux (Terminal)
```
cd group-box
node group-box.js fleet
node group-box.js scan /path/to/file-or-folder
node group-box.js ports
node group-box.js help
```

### Termux (Android)
```
pkg install nodejs
cd group-box
node group-box.js fleet
node group-box.js scan /path/to/file-or-folder
node group-box.js ports
```

### Checking the fleet on another machine on your network
```
node group-box.js fleet --host 192.168.1.23
```
(Replace the IP with the machine running the LOVEOS servers. Default is 127.0.0.1 — the machine you are standing on.)

## Verified

Verified Nov 3, 2026 on the CEO's fleet machine: `node --check` parses clean · `fleet` → all 4 servers UP (FLEET: ALL UP) · `scan` on itself → 5,223 bytes, SHA-256 `28867e9e3af1f388572f5ed86c5d200cb53c663d2df8520bca08fa2517dd9697` · `ports` → only 8787–8790 open locally, everything else closed · `help` prints usage.

---
© 2026 LOVE OS Inc. / CEO TroyFeeney. All Rights Reserved.
