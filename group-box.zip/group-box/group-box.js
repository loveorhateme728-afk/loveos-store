#!/usr/bin/env node
// LOVEOS GROUP BOX — portable security root box
// CEO TroyFeeney · LOVE OS Inc © 2026 · 100% royalties · copyright ownership policy terms rules · custom built
// Dependency-free Node.js — runs anywhere Node runs (Windows, macOS, Linux, Termux).
// DEFENSIVE AND READ-ONLY: checks on your own machines only. No exploitation, no brute force, nothing that touches other people's systems.
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const net = require('net');

const FLEET = [
  { name: 'Network Server (fluffy)', port: 8787 },
  { name: 'Live Wall Server', port: 8788 },
  { name: 'Game Server', port: 8789 },
  { name: 'GHOST Watchdog', port: 8790 }
];

const COMMON_PORTS = [22, 80, 443, 3000, 3306, 5432, 6379, 8080, 8787, 8788, 8789, 8790, 27017];

function getFlag(args, name, def) {
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--' + name && args[i + 1]) return args[i + 1];
    if (args[i].indexOf('--' + name + '=') === 0) return args[i].slice(name.length + 3);
  }
  return def;
}

function checkHealth(host, port, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (r) => { if (!settled) { settled = true; resolve(r); } };
    const req = http.get({ host: host, port: port, path: '/__health', timeout: timeoutMs }, (res) => {
      res.resume();
      res.on('end', () => done({ up: res.statusCode === 200, status: res.statusCode }));
    });
    req.on('timeout', () => { req.destroy(); done({ up: false, status: 'timeout' }); });
    req.on('error', (e) => done({ up: false, status: e.code || 'error' }));
  });
}

async function cmdFleet(args) {
  const host = getFlag(args, 'host', '127.0.0.1');
  console.log('LOVEOS GROUP BOX — FLEET CHECK · host ' + host);
  let allUp = true;
  for (const s of FLEET) {
    const r = await checkHealth(host, s.port, 2500);
    if (!r.up) allUp = false;
    console.log((r.up ? 'UP   ' : 'DOWN ') + ' :' + s.port + '  ' + s.name + (r.up ? '' : '  (' + r.status + ')'));
  }
  console.log(allUp ? 'FLEET: ALL UP' : 'FLEET: NEEDS ATTENTION');
  if (!allUp) process.exitCode = 1;
}

function sha256File(file) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash('sha256');
    const rs = fs.createReadStream(file);
    rs.on('data', (c) => h.update(c));
    rs.on('end', () => resolve(h.digest('hex')));
    rs.on('error', reject);
  });
}

function collectFiles(target, out) {
  const st = fs.statSync(target);
  if (st.isFile()) { out.push(target); return; }
  if (st.isDirectory()) {
    const entries = fs.readdirSync(target).sort();
    for (const entry of entries) collectFiles(path.join(target, entry), out);
  }
}

async function cmdScan(args) {
  const target = args.filter((a) => a.indexOf('--') !== 0)[0];
  if (!target) { console.log('Usage: node group-box.js scan <file-or-dir>'); process.exitCode = 2; return; }
  if (!fs.existsSync(target)) { console.log('Not found: ' + target); process.exitCode = 2; return; }
  const files = [];
  collectFiles(target, files);
  console.log('LOVEOS GROUP BOX — INTEGRITY SCAN · ' + target + ' · ' + files.length + ' file(s)');
  for (const f of files) {
    const size = fs.statSync(f).size;
    const hash = await sha256File(f);
    console.log(size + '\t' + hash + '\t' + f);
  }
  console.log('SHA-256 · read-only · nothing was modified.');
}

function checkPort(port, timeoutMs) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let done = false;
    const finish = (open) => { if (!done) { done = true; sock.destroy(); resolve(open); } };
    sock.setTimeout(timeoutMs);
    sock.once('connect', () => finish(true));
    sock.once('timeout', () => finish(false));
    sock.once('error', () => finish(false));
    sock.connect(port, '127.0.0.1');
  });
}

async function cmdPorts() {
  console.log('LOVEOS GROUP BOX — LOCAL PORT CHECK · 127.0.0.1 only');
  for (const p of COMMON_PORTS) {
    const open = await checkPort(p, 800);
    console.log((open ? 'OPEN   ' : 'closed ') + ' :' + p);
  }
  console.log('Connect check only — nothing probed, nothing touched.');
}

function cmdHelp() {
  console.log([
    'LOVEOS GROUP BOX — portable security root box',
    'CEO TroyFeeney · LOVE OS Inc © 2026 · 100% royalties · custom built',
    '',
    'USAGE',
    '  node group-box.js fleet [--host <ip>]   Check the 4 LOVEOS servers (ports 8787-8790, /__health)',
    '  node group-box.js scan <file-or-dir>    SHA-256 integrity scan (read-only)',
    '  node group-box.js ports                 Check common local ports on THIS machine (127.0.0.1 only)',
    '  node group-box.js help                  This help',
    '',
    'Defensive checks on your own machines only.'
  ].join('\n'));
}

(async () => {
  const cmd = process.argv[2] || 'help';
  const rest = process.argv.slice(3);
  try {
    if (cmd === 'fleet') await cmdFleet(rest);
    else if (cmd === 'scan') await cmdScan(rest);
    else if (cmd === 'ports') await cmdPorts();
    else cmdHelp();
  } catch (e) {
    console.log('ERROR: ' + (e && e.message ? e.message : e));
    process.exitCode = 1;
  }
})();
